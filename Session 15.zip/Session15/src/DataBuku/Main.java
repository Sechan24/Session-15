package DataBuku;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        BookLinkedList daftarBuku = new BookLinkedList();

        int pilihan;

        do {

            System.out.println("\n===== DATA SISTEM BUKU =====");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cari Buku");
            System.out.println("4. Lihat Semua Buku");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");

            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {

                case 1:

                    String kodeBuku;

                    do {
                        System.out.print("Masukkan Kode Buku: ");
                        kodeBuku = input.nextLine();

                        if (kodeBuku.length() > 5) {
                            System.out.println(
                                "Kode buku maksimal 5 karakter!"
                            );
                        }

                    } while (kodeBuku.length() > 5);

                    System.out.print("Masukkan Judul: ");
                    String judul = input.nextLine();

                    System.out.print("Masukkan Penulis: ");
                    String penulis = input.nextLine();

                    daftarBuku.tambahBuku(
                        kodeBuku,
                        judul,
                        penulis
                    );

                    break;

                case 2:

                    daftarBuku.hapusBuku();
                    break;

                case 3:

                    System.out.print("Masukkan Kode Buku: ");
                    String kodeCari = input.nextLine();

                    daftarBuku.cariBuku(kodeCari);
                    break;

                case 4:

                    daftarBuku.tampilkanSemuaBuku();
                    break;

                case 5:

                    System.out.println("Program selesai.");
                    break;

                default:

                    System.out.println("Pilihan tidak valid.");
            }

        } while (pilihan != 5);

        input.close();
    }
}