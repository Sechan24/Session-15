package KasirToko;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Queue antrian = new Queue();
        Stack riwayat = new Stack();

        int pilihan;

        do {

            System.out.println("\n=== SISTEM KASIR TOKO ===");
            System.out.println("1. Tambah Antrian");
            System.out.println("2. Layani Pelanggan");
            System.out.println("3. Tampilkan Antrian");
            System.out.println("4. Lihat Riwayat Transaksi");
            System.out.println("5. Keluar");

            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {

                case 1:

                    if (antrian.getJumlahPelanggan() >= 5) {
                        System.out.println(
                            "Antrian sudah mencapai maksimal 5 pelanggan."
                        );
                        break;
                    }

                    System.out.print(
                        "Masukkan Nomor Antrian: "
                    );
                    String nomor = input.nextLine();

                    System.out.print(
                        "Masukkan Nama Pelanggan: "
                    );
                    String nama = input.nextLine();

                    System.out.print(
                        "Masukkan Total Belanja: "
                    );
                    double total = input.nextDouble();

                    antrian.enqueue(
                        nomor,
                        nama,
                        total
                    );

                    break;

                case 2:

                    Node pelanggan = antrian.dequeue();

                    if (pelanggan == null) {

                        System.out.println(
                            "Tidak ada pelanggan dalam antrian."
                        );

                    } else {

                        System.out.println(
                            "\nMelayani pelanggan "
                            + pelanggan.nomorAntrian
                            + " ("
                            + pelanggan.namaPelanggan
                            + ")"
                        );

                        riwayat.push(pelanggan);

                        System.out.println(
                            "Transaksi disimpan ke riwayat."
                        );
                    }

                    break;

                case 3:

                    antrian.tampilkanAntrian();
                    break;

                case 4:

                    riwayat.display();
                    break;

                case 5:

                    System.out.println(
                        "Program selesai."
                    );
                    break;

                default:

                    System.out.println(
                        "Pilihan tidak valid."
                    );
            }

        } while (pilihan != 5);

        input.close();
    }
}