package KasirToko;

public class Stack {

    private Node top;

    // Menambahkan transaksi ke Stack
    public void push(Node transaksi) {

        transaksi.next = top;
        top = transaksi;
    }

    // Menampilkan riwayat transaksi terbaru ke lama
    public void display() {

        if (top == null) {
            System.out.println("Belum ada riwayat transaksi.");
            return;
        }

        Node current = top;

        System.out.println("\n=== RIWAYAT TRANSAKSI ===");

        while (current != null) {

            System.out.println(
                current.nomorAntrian
                + " | "
                + current.namaPelanggan
                + " | Rp "
                + current.totalBelanja
            );

            current = current.next;
        }
    }
}