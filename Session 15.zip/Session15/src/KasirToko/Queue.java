package KasirToko;

public class Queue {

    private Node front;
    private Node rear;
    private int jumlahPelanggan;

    // Menambahkan pelanggan ke antrian
    public void enqueue(
        String nomorAntrian,
        String namaPelanggan,
        double totalBelanja
    ) {

        Node newNode = new Node(
            nomorAntrian,
            namaPelanggan,
            totalBelanja
        );

        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }

        jumlahPelanggan++;

        System.out.println(
            "Data pelanggan ditambahkan ke antrian!"
        );
    }

    // Menghapus pelanggan dari depan
    public Node dequeue() {

        if (front == null) {
            return null;
        }

        Node temp = front;
        front = front.next;

        if (front == null) {
            rear = null;
        }

        temp.next = null;
        jumlahPelanggan--;

        return temp;
    }

    // Menampilkan antrian
    public void tampilkanAntrian() {

        if (front == null) {
            System.out.println("Antrian kosong.");
            return;
        }

        Node current = front;

        System.out.println("\n=== ANTRIAN PELANGGAN ===");

        while (current != null) {

            System.out.println(
                current.nomorAntrian
                + " | "
                + current.namaPelanggan
                + " | Rp "
                + current.totalBelanja
            );

            current = current.next;
        }
    }

    public int getJumlahPelanggan() {
        return jumlahPelanggan;
    }
}